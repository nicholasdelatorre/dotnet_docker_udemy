INSERT INTO `users` (`Login`, `AccessKey`) VALUES ('leandro', 'admin123');
INSERT INTO `users` (`Login`, `AccessKey`) VALUES ('flavio', 'user123');